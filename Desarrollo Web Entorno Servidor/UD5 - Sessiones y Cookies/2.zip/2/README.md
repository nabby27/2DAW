## Ejercicio para actualizar un cliente en bade de datos

Primero se pedira un dni a traves d eun formualrio y con el metodo buscar comprobaremos si existe el cliente, si no existe mostraremos un error y un vinculo para volver a empezar pero si existe se mostrara el formulario con todos los campos rellenados de manera que se pueda escribir en todos menos en el dni, y con los datos que se escribe se modificara todos los campos.
